#!/usr/bin/env bash
set -euo pipefail

SERVICE_NAME="bito-agent"
INSTALL_DIR="/opt/bito-agent"
LOG_DIR="/var/log/bito-agent"
KEEP_CONFIG=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --service-name)
      SERVICE_NAME="${2:?--service-name requires a value}"
      shift 2
      ;;
    --install-dir)
      INSTALL_DIR="${2:?--install-dir requires a value}"
      shift 2
      ;;
    --keep-config)
      KEEP_CONFIG=1
      shift
      ;;
    -h|--help)
      cat <<EOF
Usage: sudo bash uninstall.sh [options]

Options:
  --service-name NAME  systemd service name (default: bito-agent)
  --install-dir DIR    install directory (default: /opt/bito-agent)
  --keep-config        leave agent-config.yaml backup in the install directory
EOF
      exit 0
      ;;
    *)
      echo "[ERROR] unknown option: $1" >&2
      exit 2
      ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "[ERROR] root permission is required. Run: sudo bash uninstall.sh" >&2
  exit 1
fi
if [ "$INSTALL_DIR" = "/" ] || [ "$INSTALL_DIR" = "/opt" ] || [ -z "$INSTALL_DIR" ]; then
  echo "[ERROR] unsafe install directory: $INSTALL_DIR" >&2
  exit 1
fi

echo "============================================"
echo "  ViTO Agent Linux uninstaller"
echo "============================================"
echo "service:     $SERVICE_NAME"
echo "install dir: $INSTALL_DIR"
echo

printf "Continue uninstall? [y/N] "
read -r confirm
case "$confirm" in
  y|Y|yes|YES) ;;
  *)
    echo "Uninstall cancelled."
    exit 0
    ;;
esac

echo "[1/4] stopping and disabling service"
systemctl stop "$SERVICE_NAME" 2>/dev/null || true
systemctl disable "$SERVICE_NAME" 2>/dev/null || true

echo "[2/4] removing systemd unit"
rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload

echo "[3/4] backing up config"
BACKUP_FILE=""
if [ -f "$INSTALL_DIR/agent-config.yaml" ]; then
  BACKUP_DIR="/var/backups/bito-agent"
  mkdir -p "$BACKUP_DIR"
  BACKUP_FILE="$BACKUP_DIR/${SERVICE_NAME}-agent-config-$(date +%Y%m%d%H%M%S).yaml"
  cp "$INSTALL_DIR/agent-config.yaml" "$BACKUP_FILE"
  echo "[INFO] config backup: $BACKUP_FILE"
fi

echo "[4/4] removing files"
if [ "$KEEP_CONFIG" -eq 1 ] && [ -f "$INSTALL_DIR/agent-config.yaml" ]; then
  find "$INSTALL_DIR" -mindepth 1 ! -name "agent-config.yaml" -exec rm -rf {} +
else
  rm -rf "$INSTALL_DIR"
fi
rm -rf "$LOG_DIR"

echo
echo "ViTO Agent uninstall complete."
if [ -n "$BACKUP_FILE" ]; then
  echo "Config backup: $BACKUP_FILE"
fi
