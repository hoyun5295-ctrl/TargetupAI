# Bito Agent Linux 설치 가이드

## 패키지 구성

- `bito-agent`: linux-amd64 정적 실행 파일
- `agent-config.example.yaml`: 런타임 설정 예시
- `install.sh`: `doctor` 사전 점검을 포함한 설치 스크립트
- `uninstall.sh`: 삭제 스크립트
- `bito-agent.service`: systemd 서비스 템플릿
- `VERSION.txt`: 버전, 커밋, 빌드 시각, 대상 플랫폼
- `checksums.sha256`: 패키지 내부 파일 checksum

## 설치 전 준비값

설치 전에 아래 값을 준비하십시오.

- 발급받은 `agent_id`
- 발급받은 `gateway.token`
- Gateway host, port, TLS 사용 여부
- 고객사 DB host, port, database, username, password
- 고객사 발송 테이블명과 컬럼 매핑
- Bito Gateway에 등록된 고객사 outbound NAT 공인 IP 또는 승인 CIDR

Gateway는 token이 맞아도 등록되지 않은 출발지 IP/CIDR에서 들어오는 Agent 연결을 거부합니다.

## 설치

```bash
tar -xzf Bito-Agent-v1.0.5-linux-amd64.tar.gz
cd Bito-Agent-v1.0.5-linux-amd64
cp agent-config.example.yaml agent-config.yaml
vi agent-config.yaml
sudo bash install.sh
```

## 읽기 전용 매핑 추천

서비스 시작 전 고객사 테이블을 읽기 전용으로 분석하려면 아래 명령을 사용합니다.

```bash
./bito-agent discover --config agent-config.yaml --table CUSTOMER_SEND_TABLE
./bito-agent onboard --config agent-config.yaml --table CUSTOMER_SEND_TABLE --output agent-config.yaml
```

이 명령은 추천 `field_map`, `status_values`, `msg_type_values`, `state_policy`, `result_policy`, `kakao_payload_map`, journal 경로를 터미널에 출력합니다. Discovery/onboard 단계는 SELECT만 수행하며 고객사 DB를 UPDATE하지 않습니다.

Superadmin에서 승인하는 경우에는 최종 YAML을 고객 서버에 복사하기 전에 자동 커스터마이징 게이트의 매핑, 정책, Secret, YAML 단계를 확인하십시오. 알림톡/친구톡/브랜드메시지 profile은 고객사 테이블에 attachment, carousel, business code, user map, brand bubble 계열 필드가 있을 때 `kakao_payload_map` 또는 `field_map.kakao_payload`가 포함되어야 합니다.

카카오 실패 문자전환은 v1.0.5 기준 Gateway 관리형 처리가 표준입니다. 실서비스 전 `kakao_failover` 플래그, 대체본문 매핑, `kakao_failover_sms`, `kakao_failover_lms` 성공코드가 설정되어 있는지 확인하십시오.

Gateway 접속이 아직 열리지 않았으면 DB와 매핑 사전 점검만 먼저 실행할 수 있습니다.

```bash
sudo bash install.sh --skip-gateway
```

## 사전 점검

설치 스크립트는 서비스 등록 전에 아래 명령을 실행합니다.

```bash
/opt/bito-agent/bito-agent doctor --config /opt/bito-agent/agent-config.yaml --log-dir /var/log/bito-agent
```

`doctor` 결과에 `FAIL`이 하나라도 있으면 설정, 권한, 네트워크 문제를 먼저 조치하고 서비스 시작을 진행하지 마십시오. `state_policy.mode`가 `final_result_only` 또는 `external_journal`이면 `state_policy.journal_path` 쓰기 권한도 함께 확인합니다.

런타임 DB 계정이 결과 컬럼을 UPDATE할 수 있는지 확인하려면 안전한 테스트 pending row 1건을 준비한 뒤 아래 옵션을 사용합니다.

```bash
sudo bash install.sh --check-runtime-write
```

이 점검은 transaction 안에서 no-op UPDATE를 수행한 뒤 rollback합니다.

## 용량 튜닝 기본값

기본 런타임 값은 정합성을 우선한 보수적 설정입니다.

```yaml
batch_size: 100
send_concurrency: 1
report_concurrency: 1
```

대량 벤치에서는 먼저 `batch_size: 200`, `send_concurrency: 1`, `report_concurrency: 1`로 100,000건 정합성 gate를 확인합니다. 정합성은 PASS지만 sustained TPS가 300 미만이면 다음 단계에서 `report_concurrency: 4`만 분리해 측정하십시오. 100,000건 gate와 목표 TPS가 닫히기 전에는 1,000,000건 이상으로 확대하지 않습니다.

## 서비스 명령

```bash
sudo systemctl status bito-agent
sudo systemctl restart bito-agent
sudo systemctl stop bito-agent
journalctl -u bito-agent -f
```

## 삭제

```bash
sudo bash uninstall.sh
```

삭제 스크립트는 서비스 제거 전에 `agent-config.yaml`을 백업합니다.

## QTmsg 전환 메모

QTmsg는 대체 대상이지 호환 목표가 아닙니다. 기존 `SMSQ_SEND`, `Rsv1`, `status_code` 형태의 테이블은 전환 입력 스키마로만 취급합니다. QTmsg형 테이블에서는 `done`과 `failed`가 모두 `Rsv1=4`로 매핑될 수 있으며, 최종 성공/실패는 `status_code`로 판단합니다.
