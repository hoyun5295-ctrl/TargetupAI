#!/usr/bin/env bash
set -euo pipefail

SERVICE_NAME="bito-agent"
INSTALL_DIR="/opt/bito-agent"
SERVICE_USER="root"
LOG_DIR="/var/log/bito-agent"
SKIP_GATEWAY=0
CHECK_RUNTIME_WRITE=0
NO_START=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --service-name)
      SERVICE_NAME="${2:?--service-name requires a value}"
      shift 2
      ;;
    --install-dir)
      INSTALL_DIR="${2:?--install-dir requires a value}"
      shift 2
      ;;
    --user)
      SERVICE_USER="${2:?--user requires a value}"
      shift 2
      ;;
    --skip-gateway)
      SKIP_GATEWAY=1
      shift
      ;;
    --check-runtime-write)
      CHECK_RUNTIME_WRITE=1
      shift
      ;;
    --no-start)
      NO_START=1
      shift
      ;;
    -h|--help)
      cat <<EOF
Usage: sudo bash install.sh [options]

Options:
  --service-name NAME  systemd service name (default: bito-agent)
  --install-dir DIR    install directory (default: /opt/bito-agent)
  --user USER          systemd service user (default: root)
  --skip-gateway       pass --skip-gateway to agent doctor
  --check-runtime-write run rollback-based runtime UPDATE permission probe
  --no-start           install and enable service but do not start it
EOF
      exit 0
      ;;
    *)
      echo "[ERROR] unknown option: $1" >&2
      exit 2
      ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "[ERROR] root permission is required. Run: sudo bash install.sh" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BINARY_SRC="$SCRIPT_DIR/bito-agent"
EXAMPLE_SRC="$SCRIPT_DIR/agent-config.example.yaml"
UNIT_TEMPLATE="$SCRIPT_DIR/bito-agent.service"

if [ ! -f "$BINARY_SRC" ]; then
  echo "[ERROR] missing binary: $BINARY_SRC" >&2
  exit 1
fi
if [ ! -f "$EXAMPLE_SRC" ]; then
  echo "[ERROR] missing config example: $EXAMPLE_SRC" >&2
  exit 1
fi
if [ ! -f "$UNIT_TEMPLATE" ]; then
  echo "[ERROR] missing systemd template: $UNIT_TEMPLATE" >&2
  exit 1
fi

echo "============================================"
echo "  ViTO Agent Linux installer"
echo "============================================"
echo "service:     $SERVICE_NAME"
echo "install dir: $INSTALL_DIR"
echo "user:        $SERVICE_USER"
echo

if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
  echo "[INFO] stopping existing service: $SERVICE_NAME"
  systemctl stop "$SERVICE_NAME"
fi

echo "[1/5] installing files"
mkdir -p "$INSTALL_DIR" "$LOG_DIR"
cp "$BINARY_SRC" "$INSTALL_DIR/bito-agent"
chmod 0755 "$INSTALL_DIR/bito-agent"
cp "$EXAMPLE_SRC" "$INSTALL_DIR/agent-config.example.yaml"

if [ -f "$SCRIPT_DIR/agent-config.yaml" ]; then
  if [ -f "$INSTALL_DIR/agent-config.yaml" ]; then
    cp "$SCRIPT_DIR/agent-config.yaml" "$INSTALL_DIR/agent-config.yaml.new"
    echo "[INFO] existing config preserved; new package config copied to agent-config.yaml.new"
  else
    cp "$SCRIPT_DIR/agent-config.yaml" "$INSTALL_DIR/agent-config.yaml"
  fi
elif [ ! -f "$INSTALL_DIR/agent-config.yaml" ]; then
  cp "$EXAMPLE_SRC" "$INSTALL_DIR/agent-config.yaml"
  echo "[WARN] created agent-config.yaml from the example. Edit it before production use."
fi

echo "[2/5] agent version"
"$INSTALL_DIR/bito-agent" version

echo "[3/5] running doctor preflight"
DOCTOR_ARGS=(doctor --config "$INSTALL_DIR/agent-config.yaml" --timeout 5s --log-dir "$LOG_DIR")
if [ "$SKIP_GATEWAY" -eq 1 ]; then
  DOCTOR_ARGS+=(--skip-gateway)
fi
if [ "$CHECK_RUNTIME_WRITE" -eq 1 ]; then
  DOCTOR_ARGS+=(--check-runtime-write)
fi
if ! "$INSTALL_DIR/bito-agent" "${DOCTOR_ARGS[@]}"; then
  cat <<EOF

[ERROR] doctor failed. Service registration/start is blocked.
Fix $INSTALL_DIR/agent-config.yaml, then rerun this installer.
If the Gateway is not available yet, rerun with --skip-gateway for DB/mapping preflight only.
EOF
  exit 1
fi

echo "[4/5] installing systemd unit"
UNIT_PATH="/etc/systemd/system/${SERVICE_NAME}.service"
sed \
  -e "s#{{SERVICE_NAME}}#$SERVICE_NAME#g" \
  -e "s#{{INSTALL_DIR}}#$INSTALL_DIR#g" \
  -e "s#{{SERVICE_USER}}#$SERVICE_USER#g" \
  -e "s#{{LOG_DIR}}#$LOG_DIR#g" \
  "$UNIT_TEMPLATE" > "$UNIT_PATH"
chmod 0644 "$UNIT_PATH"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"

echo "[5/5] starting service"
if [ "$NO_START" -eq 1 ]; then
  echo "[INFO] --no-start selected. Start manually: sudo systemctl start $SERVICE_NAME"
else
  systemctl restart "$SERVICE_NAME"
fi

echo
echo "============================================"
echo "  ViTO Agent installation complete"
echo "============================================"
echo "Config:  $INSTALL_DIR/agent-config.yaml"
echo "Status:  systemctl status $SERVICE_NAME"
echo "Logs:    journalctl -u $SERVICE_NAME -f"
